# MELD Validation

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)

Reference implementation of the **Medicare Enhanced Linked Database (MELD)**
validation framework described in:

> Baser O. *Validation of the Medicare Enhanced Linked Database (MELD): A
> Nine-Block Framework for Real-World Evidence in the Medicare 65+ Population.*
> Journal of Health Economics and Outcomes Research (JHEOR), 2026.

This repository provides a reproducible Python pipeline matching the nine
validation blocks (A through I) in Section 3 of the paper. Every function
cites the corresponding equation number (Eq 1 – Eq 17) from the manuscript.

---

## What this code does

MELD is an integrated Medicare claims resource for the U.S. 65+ population.
Before it can be used for policy, HEOR, or regulatory research, it must be
validated across nine dimensions. This repo operationalizes that pipeline:

| Block | Domain                               | Key statistics                                      |
|-------|--------------------------------------|-----------------------------------------------------|
| A     | Internal consistency                 | Cronbach's α (Eq 1), KR-20 (Eq 2), bootstrap 95% CI |
| B     | Concurrent / criterion validity      | Prevalence bias (Eq 3), MAPE (Eq 4), Bland–Altman LoA (Eq 5), Lin's CCC (Eq 6) |
| C     | Construct validity (CFA)             | CFI, TLI, RMSEA, SRMR (Eq 7)                        |
| D     | Population representativeness        | SMD (Eq 8), post-stratification weights (Eq 9)      |
| E     | Missingness & imputation             | Little's MCAR (Eq 10), Rubin's rules (Eq 11), MICE m=20 |
| F     | Record linkage                       | Fellegi–Sunter weights (Eq 12), decision rule (Eq 13) |
| G     | Inter-coder agreement                | Cohen's κ (Eq 14)                                   |
| H     | Temporal stability                   | Mann–Kendall (Eq 15), CUSUM control                 |
| I     | Predictive validity                  | Calibration slope/intercept (Eq 16), Brier, AUROC   |
| +     | Multivariate outliers                | Mahalanobis D² (Eq 17)                              |

Thresholds (α ≥ 0.80, SMD < 0.10, CCC ≥ 0.90, CFI/TLI ≥ 0.95, RMSEA ≤ 0.06,
SRMR ≤ 0.08, κ ≥ 0.61, FS false-match ≤ 0.005) are encoded in
`ValidationConfig`.

---

## Installation

Requires Python 3.10 or newer.

```bash
git clone https://github.com/obaser/meld-validation.git
cd meld-validation
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

---

## Quickstart — library API

```python
import pandas as pd
from meld_validation import MELDValidator, ValidationConfig

config = ValidationConfig()  # defaults match the paper
validator = MELDValidator(config)

inputs = {
    # Block A
    "likert_items": pd.DataFrame(...),       # multi-item Likert scales
    "binary_items": pd.DataFrame(...),       # dichotomous items
    # Block B
    "claims_prevalence": {...},              # dict[condition] -> rate
    "benchmark_prevalence": {...},           # e.g. CDC / MEPS rates
    "claims_estimates": [...],               # per-beneficiary estimates
    "gold_estimates":  [...],                # gold-standard estimates
    # Block C
    "cfa_data": pd.DataFrame(...),
    "cfa_model": "F1 =~ x1 + x2 + x3\nF2 =~ y1 + y2 + y3",
    # Block D
    "meld_covariates": pd.DataFrame(...),
    "target_covariates": pd.DataFrame(...),  # Medicare Master Beneficiary Summary
    # Block E
    "missingness_frame": pd.DataFrame(...),
    # Block F
    "linkage_a": pd.DataFrame(...), "linkage_b": pd.DataFrame(...),
    # Block G
    "coder1": [...], "coder2": [...],
    # Block H
    "time_series": pd.Series(...),
    # Block I
    "y_true": [...], "y_pred_proba": [...],
}

report = validator.run_all(inputs)
report.to_json("validation_report.json")
print(report.summary())
```

Any block can be run individually:

```python
alpha, ci = validator.run_block_a(likert_items=inputs["likert_items"])
fit = validator.run_block_c(data=inputs["cfa_data"], model_desc=inputs["cfa_model"])
```

---

## Quickstart — CLI

```bash
python meld_validation.py \
    --config configs/meld_2026.yaml \
    --out   output/validation_report.json
```

The YAML config points at parquet/CSV inputs for each block; see
`meld_validation.py --help` for the full list.

---

## Repository layout

```
meld-validation/
├── meld_validation.py        # Main module: all nine blocks + CLI
├── requirements.txt
├── README.md
├── LICENSE                   # MIT
├── .gitignore
├── src/                      # (reserved for future sub-modules)
└── tests/
    └── test_validators.py    # Smoke tests on toy data
```

---

## Reproducibility

- Random seed = `2026` (matches the paper year) is set globally in
  `ValidationConfig`.
- MICE uses `m = 20` imputations, pooled by Rubin's rules.
- Bootstrap 95% CIs use `n_bootstrap = 1000`.
- All thresholds live in `ValidationConfig` — override them explicitly to
  document any deviation from the paper.

---

## Data access

This repository contains **no patient-level data**. MELD analytic files
require a CMS Data Use Agreement (DUA). See the paper's Data Availability
statement for details.

---

## Citation

If you use this code, please cite:

```bibtex
@article{baser2026meld,
  author  = {Baser, Onur},
  title   = {Validation of the Medicare Enhanced Linked Database (MELD):
             A Nine-Block Framework for Real-World Evidence in the
             Medicare 65+ Population},
  journal = {Journal of Health Economics and Outcomes Research},
  year    = {2026}
}
```

---

## License

[MIT](./LICENSE) © 2026 Onur Baser, CUNY Graduate School of Public Health
and Health Policy.
