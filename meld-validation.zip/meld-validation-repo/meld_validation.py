"""
meld_validation.py
==================

Reference implementation of the validation pipeline reported in:

    Baser O. "Validation of the MELD(TM) Dataset: A Multi-Domain Psychometric,
    Epidemiologic, and Predictive Assessment of a Linked Medicare-EMR Resource."
    Journal of Health Economics and Outcomes Research (submitted, 2026).

This module implements the 7-block validation framework described in Section 3
of the manuscript:

    Block A  Internal consistency      Cronbach's alpha, KR-20, Lin's CCC
    Block B  Concurrent validity       Bias, MAPE, Bland-Altman, Lin's CCC vs CMS
    Block C  Construct validity        CFA (CFI, TLI, RMSEA, SRMR)
    Block D  Coverage & representativeness  SMD, post-stratification weights
    Block E  Missing-data diagnostics  Little's MCAR, MICE (Rubin's rules)
    Block F  Record linkage            Fellegi-Sunter with EM
    Block G  Coding concordance        Cohen's kappa
    Block H  Temporal stability        Mann-Kendall trend, CUSUM
    Block I  Predictive validity       LASSO/XGBoost, AUROC, Brier, calibration

Author:  Onur Baser, School of Public Health, City University of New York
License: MIT

Usage
-----
    # As a library
    from meld_validation import MELDValidator
    validator = MELDValidator(config_path="config.yaml")
    report = validator.run_all()
    validator.save_report("validation_report.json")

    # From the command line
    python meld_validation.py --config config.yaml --out validation_report.json

Dependencies
------------
    numpy, pandas, scipy, scikit-learn, statsmodels, semopy,
    recordlinkage, xgboost, pyyaml

See requirements.txt for pinned versions.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger("meld_validation")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class ValidationConfig:
    """Runtime configuration for the MELD validation pipeline."""

    # Thresholds (match manuscript Section 3)
    alpha_threshold: float = 0.80       # Cronbach's alpha acceptance cut
    smd_threshold: float = 0.10         # Standardized mean difference
    ccc_threshold: float = 0.90         # Lin's concordance correlation
    cfi_threshold: float = 0.95
    tli_threshold: float = 0.95
    rmsea_threshold: float = 0.06
    srmr_threshold: float = 0.08
    kappa_threshold: float = 0.61       # Landis-Koch "substantial" floor

    # Fellegi-Sunter thresholds
    fs_false_match_rate: float = 0.005      # upper bound on mu
    fs_false_nonmatch_rate: float = 0.050   # upper bound on lambda

    # Imputation
    mice_m_imputations: int = 20

    # Bootstrap
    n_bootstrap: int = 1000
    random_seed: int = 2026

    # Data paths (injected at runtime)
    meld_path: Optional[str] = None
    cms_benchmark_path: Optional[str] = None
    census_path: Optional[str] = None
    output_dir: str = "output"


# ---------------------------------------------------------------------------
# Block A - Internal consistency and reliability
# ---------------------------------------------------------------------------

def cronbach_alpha(items: np.ndarray) -> float:
    """
    Cronbach's alpha (Equation 1 in the manuscript).

        alpha = (k / (k - 1)) * (1 - sum(var_i) / var_T)

    Parameters
    ----------
    items : (n, k) array of item scores (rows = respondents, cols = items)

    Returns
    -------
    float : Cronbach's alpha in [-inf, 1]

    Notes
    -----
    Undefined for k = 1 (returns NaN). Typical acceptance >= 0.80.
    """
    items = np.asarray(items, dtype=float)
    if items.ndim != 2:
        raise ValueError("items must be a 2D array with rows = respondents")
    n, k = items.shape
    if k < 2:
        return float("nan")
    item_vars = items.var(axis=0, ddof=1)
    total_var = items.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return float("nan")
    return (k / (k - 1)) * (1 - item_vars.sum() / total_var)


def kr20(binary_items: np.ndarray) -> float:
    """
    Kuder-Richardson 20 (Equation 2), the dichotomous analog of alpha.

        KR-20 = (k / (k - 1)) * (1 - sum(p_i * (1 - p_i)) / var_T)
    """
    binary_items = np.asarray(binary_items, dtype=float)
    if not np.all(np.isin(binary_items, [0.0, 1.0])):
        raise ValueError("KR-20 requires 0/1 item responses")
    n, k = binary_items.shape
    if k < 2:
        return float("nan")
    p = binary_items.mean(axis=0)
    pq_sum = (p * (1 - p)).sum()
    total_var = binary_items.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return float("nan")
    return (k / (k - 1)) * (1 - pq_sum / total_var)


def bootstrap_ci(
    data: np.ndarray,
    stat_fn,
    n_boot: int = 1000,
    alpha: float = 0.05,
    rng: Optional[np.random.Generator] = None,
) -> Tuple[float, float]:
    """Nonparametric percentile bootstrap confidence interval for a statistic."""
    rng = rng or np.random.default_rng()
    n = len(data)
    reps = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, n)
        reps[b] = stat_fn(data[idx]) if data.ndim == 1 else stat_fn(data[idx, :])
    lo, hi = np.quantile(reps, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


# ---------------------------------------------------------------------------
# Block B - Concurrent validity (vs. CMS Medicare benchmarks)
# ---------------------------------------------------------------------------

def prevalence_bias(meld: np.ndarray, cms: np.ndarray) -> float:
    """Equation 3: mean (MELD - CMS) prevalence across J indications."""
    meld, cms = np.asarray(meld, float), np.asarray(cms, float)
    return float(np.mean(meld - cms))


def mape(meld: np.ndarray, cms: np.ndarray) -> float:
    """Equation 4: mean absolute percentage error, guarding against division by 0."""
    meld, cms = np.asarray(meld, float), np.asarray(cms, float)
    mask = cms != 0
    return float(np.mean(np.abs(meld[mask] - cms[mask]) / cms[mask]))


def bland_altman_loa(
    meld: np.ndarray, cms: np.ndarray
) -> Tuple[float, float, float]:
    """
    Equation 5: Bland-Altman 95% limits of agreement.

    Returns (mean_bias, lower_loa, upper_loa).
    """
    diffs = np.asarray(meld, float) - np.asarray(cms, float)
    mean_d = float(diffs.mean())
    sd_d = float(diffs.std(ddof=1))
    return mean_d, mean_d - 1.96 * sd_d, mean_d + 1.96 * sd_d


def lin_ccc(x: np.ndarray, y: np.ndarray) -> float:
    """
    Equation 6: Lin's concordance correlation coefficient.

        rho_c = 2 * s_xy / (s_x^2 + s_y^2 + (xbar - ybar)^2)
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    sx2 = x.var(ddof=1)
    sy2 = y.var(ddof=1)
    sxy = np.cov(x, y, ddof=1)[0, 1]
    return float(2 * sxy / (sx2 + sy2 + (x.mean() - y.mean()) ** 2))


# ---------------------------------------------------------------------------
# Block C - Construct validity (CFA)
# ---------------------------------------------------------------------------

def fit_cfa(data: pd.DataFrame, model_spec: str) -> Dict[str, float]:
    """
    Fit a confirmatory factor analysis model and return the fit indices
    reported in Section 4.4:  chi2/df, CFI, TLI, RMSEA, SRMR.

    Requires ``semopy``.  Falls back to a descriptive error if unavailable.
    """
    try:
        import semopy
    except ImportError as e:
        raise ImportError(
            "CFA requires 'semopy'. Install with `pip install semopy`."
        ) from e

    model = semopy.Model(model_spec)
    model.fit(data, obj="MLW")
    stats_ = semopy.calc_stats(model)
    out = stats_.iloc[0].to_dict()
    return {
        "chi2": float(out.get("chi2", np.nan)),
        "df": float(out.get("DoF", np.nan)),
        "chi2_df": float(out.get("chi2", np.nan) / max(out.get("DoF", 1), 1)),
        "CFI": float(out.get("CFI", np.nan)),
        "TLI": float(out.get("TLI", np.nan)),
        "RMSEA": float(out.get("RMSEA", np.nan)),
        "SRMR": float(out.get("SRMR", np.nan)),
    }


# ---------------------------------------------------------------------------
# Block D - Coverage, representativeness, post-stratification weighting
# ---------------------------------------------------------------------------

def standardized_mean_difference(
    mu1: float, sd1: float, mu2: float, sd2: float
) -> float:
    """
    Equation 8: SMD between two distributions.

        SMD = (mu1 - mu2) / sqrt((sd1^2 + sd2^2) / 2)
    """
    pooled = math.sqrt((sd1 ** 2 + sd2 ** 2) / 2)
    return (mu1 - mu2) / pooled if pooled > 0 else float("nan")


def smd_binary(p1: float, p2: float) -> float:
    """SMD for binary proportions (Austin 2009, Stat Med 28:3083-3107)."""
    pooled = math.sqrt((p1 * (1 - p1) + p2 * (1 - p2)) / 2)
    return (p1 - p2) / pooled if pooled > 0 else float("nan")


def poststrat_weights(
    meld_counts: Dict[str, int], pop_counts: Dict[str, int]
) -> Dict[str, float]:
    """
    Equation 9: post-stratification weights w_s = N_pop_s / N_meld_s.

    Both dictionaries are keyed by stratum id (e.g. "age65_74_female_south").
    """
    weights = {}
    for stratum, n_meld in meld_counts.items():
        n_pop = pop_counts.get(stratum, 0)
        weights[stratum] = n_pop / n_meld if n_meld > 0 else 0.0
    return weights


# ---------------------------------------------------------------------------
# Block E - Missing-data diagnostics (Little's MCAR + MICE via Rubin's rules)
# ---------------------------------------------------------------------------

def littles_mcar_test(df: pd.DataFrame) -> Dict[str, float]:
    """
    Equation 10: Little's chi-squared MCAR test.

    Approximate implementation using the EM-based sufficient statistics
    (sample-mean / sample-covariance) computed on each missingness pattern.

    Returns dict with keys: chi2, df, p_value, cramer_v.
    """
    X = df.to_numpy(dtype=float)
    missing = np.isnan(X)
    patterns, pattern_idx = np.unique(missing, axis=0, return_inverse=True)
    # EM estimate of (mu, Sigma) under MCAR via complete-case; suitable for
    # large Medicare samples where complete cases dominate.
    cc = X[~missing.any(axis=1)]
    if cc.shape[0] < X.shape[1] + 1:
        raise ValueError("Too few complete cases for a stable MCAR test.")
    mu = cc.mean(axis=0)
    Sigma = np.cov(cc, rowvar=False)
    # Regularize for numerical stability
    Sigma += 1e-8 * np.eye(Sigma.shape[0])
    Sigma_inv = np.linalg.inv(Sigma)

    chi2 = 0.0
    df_total = 0
    for k in range(len(patterns)):
        rows = pattern_idx == k
        observed_cols = ~patterns[k]
        if not observed_cols.any():
            continue
        n_k = rows.sum()
        x_bar_k = np.nanmean(X[rows][:, observed_cols], axis=0)
        mu_k = mu[observed_cols]
        Sigma_k = Sigma_inv[np.ix_(observed_cols, observed_cols)]
        d = x_bar_k - mu_k
        chi2 += n_k * float(d @ Sigma_k @ d)
        df_total += observed_cols.sum()

    df_final = max(df_total - X.shape[1], 1)
    p = 1 - stats.chi2.cdf(chi2, df_final)
    cramer_v = math.sqrt(chi2 / (X.shape[0] * (min(X.shape) - 1)))
    return {"chi2": chi2, "df": df_final, "p_value": p, "cramer_v": cramer_v}


def rubin_combine(
    theta_hats: Sequence[float], variances: Sequence[float]
) -> Dict[str, float]:
    """
    Equation 11: Rubin's combining rules across m multiple imputations.

        theta_bar = mean(theta_l)
        T         = W_bar + (1 + 1/m) * B
    """
    m = len(theta_hats)
    theta_bar = float(np.mean(theta_hats))
    W = float(np.mean(variances))
    B = float(np.var(theta_hats, ddof=1))
    T = W + (1 + 1 / m) * B
    return {"theta": theta_bar, "within_var": W, "between_var": B, "total_var": T}


# ---------------------------------------------------------------------------
# Block F - Record linkage (Fellegi-Sunter)
# ---------------------------------------------------------------------------

def fellegi_sunter_weights(
    m_probs: np.ndarray,
    u_probs: np.ndarray,
    gamma: np.ndarray,
) -> np.ndarray:
    """
    Equation 12: log-likelihood match weight for each pair.

        w(gamma) = sum_i  log2( m_i^gamma_i * (1 - m_i)^(1 - gamma_i) /
                                u_i^gamma_i * (1 - u_i)^(1 - gamma_i) )

    Parameters
    ----------
    m_probs, u_probs : (p,) arrays of agreement probabilities
    gamma            : (n, p) binary agreement indicators for n candidate pairs

    Returns
    -------
    (n,) array of log2-odds match weights.
    """
    m_probs = np.clip(np.asarray(m_probs, float), 1e-9, 1 - 1e-9)
    u_probs = np.clip(np.asarray(u_probs, float), 1e-9, 1 - 1e-9)
    gamma = np.asarray(gamma, float)
    num = gamma * np.log2(m_probs) + (1 - gamma) * np.log2(1 - m_probs)
    den = gamma * np.log2(u_probs) + (1 - gamma) * np.log2(1 - u_probs)
    return (num - den).sum(axis=1)


def fs_decision(
    weights: np.ndarray, t_match: float, t_nonmatch: float
) -> np.ndarray:
    """
    Equation 13: Fellegi-Sunter decision rule.

    Returns an integer array with values:
        1  = match              (w >= t_match)
        0  = non-match          (w <= t_nonmatch)
       -1  = clerical review    (between the two thresholds)
    """
    decisions = np.full_like(weights, -1, dtype=int)
    decisions[weights >= t_match] = 1
    decisions[weights <= t_nonmatch] = 0
    return decisions


# ---------------------------------------------------------------------------
# Block G - Coding concordance (Cohen's kappa)
# ---------------------------------------------------------------------------

def cohens_kappa(a: np.ndarray, b: np.ndarray) -> float:
    """Equation 14: Cohen's kappa for two raters on a binary condition."""
    a = np.asarray(a, int)
    b = np.asarray(b, int)
    n = len(a)
    p_o = float((a == b).mean())
    p_e = float(
        (a.mean() * b.mean()) + ((1 - a.mean()) * (1 - b.mean()))
    )
    return (p_o - p_e) / (1 - p_e) if p_e < 1 else float("nan")


# ---------------------------------------------------------------------------
# Block H - Temporal stability (Mann-Kendall)
# ---------------------------------------------------------------------------

def mann_kendall(x: np.ndarray) -> Dict[str, float]:
    """
    Equation 15: Mann-Kendall nonparametric trend test.

    Returns S, Kendall's tau, variance of S, z-statistic, and two-sided p.
    """
    x = np.asarray(x, float)
    n = len(x)
    if n < 3:
        raise ValueError("Mann-Kendall needs at least 3 observations")
    s = 0
    for i in range(n - 1):
        s += int(np.sum(np.sign(x[i + 1:] - x[i])))
    tau = s / (0.5 * n * (n - 1))
    var_s = n * (n - 1) * (2 * n + 5) / 18
    if s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"S": float(s), "tau": float(tau), "var_S": float(var_s),
            "z": float(z), "p_value": float(p)}


def cusum_control(x: np.ndarray, k: float = 0.5, h: float = 5.0) -> np.ndarray:
    """
    Two-sided CUSUM control chart with symmetric decision interval (h, k).
    Flags quarters whose cumulative deviation exceeds h * sigma.
    """
    x = np.asarray(x, float)
    mu = x.mean()
    sigma = x.std(ddof=1)
    if sigma == 0:
        return np.zeros_like(x, dtype=bool)
    pos = np.zeros_like(x)
    neg = np.zeros_like(x)
    for i in range(1, len(x)):
        pos[i] = max(0.0, pos[i - 1] + (x[i] - mu) / sigma - k)
        neg[i] = max(0.0, neg[i - 1] - (x[i] - mu) / sigma - k)
    return (pos > h) | (neg > h)


# ---------------------------------------------------------------------------
# Block I - Predictive validity
# ---------------------------------------------------------------------------

def calibration_slope_intercept(
    y_true: np.ndarray, y_prob: np.ndarray
) -> Dict[str, float]:
    """
    Equation 16: logistic calibration slope and intercept.

        logit(P(Y=1 | phat)) = alpha + gamma * logit(phat)
    """
    from sklearn.linear_model import LogisticRegression

    y_true = np.asarray(y_true, int)
    y_prob = np.clip(np.asarray(y_prob, float), 1e-6, 1 - 1e-6)
    logit_p = np.log(y_prob / (1 - y_prob)).reshape(-1, 1)
    model = LogisticRegression(penalty=None, solver="lbfgs").fit(logit_p, y_true)
    return {"intercept": float(model.intercept_[0]),
            "slope": float(model.coef_[0, 0])}


def brier_score(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Mean squared error between predicted probability and observed outcome."""
    y_true = np.asarray(y_true, float)
    y_prob = np.asarray(y_prob, float)
    return float(np.mean((y_prob - y_true) ** 2))


def auroc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Area under the ROC curve. Delegates to scikit-learn for vectorized speed."""
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y_true, y_prob))


# ---------------------------------------------------------------------------
# Multivariate outliers - Mahalanobis distance (Equation 17)
# ---------------------------------------------------------------------------

def mahalanobis_flags(
    X: np.ndarray, chi2_quantile: float = 0.999
) -> np.ndarray:
    """
    Flag rows whose Mahalanobis distance exceeds the chi-squared(p, q) threshold.
    """
    X = np.asarray(X, float)
    mu = X.mean(axis=0)
    Sigma = np.cov(X, rowvar=False)
    Sigma += 1e-8 * np.eye(Sigma.shape[0])
    Sigma_inv = np.linalg.inv(Sigma)
    d2 = np.einsum("ij,jk,ik->i", X - mu, Sigma_inv, X - mu)
    threshold = stats.chi2.ppf(chi2_quantile, df=X.shape[1])
    return d2 > threshold


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

@dataclass
class ValidationReport:
    """Structured results from a full validation run."""
    block_a: Dict[str, Any] = field(default_factory=dict)   # reliability
    block_b: Dict[str, Any] = field(default_factory=dict)   # concurrent
    block_c: Dict[str, Any] = field(default_factory=dict)   # construct
    block_d: Dict[str, Any] = field(default_factory=dict)   # coverage
    block_e: Dict[str, Any] = field(default_factory=dict)   # missingness
    block_f: Dict[str, Any] = field(default_factory=dict)   # linkage
    block_g: Dict[str, Any] = field(default_factory=dict)   # concordance
    block_h: Dict[str, Any] = field(default_factory=dict)   # temporal
    block_i: Dict[str, Any] = field(default_factory=dict)   # predictive
    config: Dict[str, Any] = field(default_factory=dict)

    def to_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2, default=str))


class MELDValidator:
    """
    High-level driver that loads MELD, runs all 9 validation blocks, and
    emits a structured JSON report matching Tables 1-4 in the paper.

    Example
    -------
    >>> validator = MELDValidator(config=ValidationConfig(meld_path="meld.parquet"))
    >>> report = validator.run_all()
    >>> report.to_json("validation_report.json")
    """

    def __init__(self, config: ValidationConfig | None = None):
        self.config = config or ValidationConfig()
        self.report = ValidationReport(config=asdict(self.config))
        self._rng = np.random.default_rng(self.config.random_seed)

    # ------------------------------------------------------------------
    # Data loading  (subclass and override for site-specific loaders)
    # ------------------------------------------------------------------
    def load_meld(self) -> pd.DataFrame:
        if not self.config.meld_path:
            raise ValueError("config.meld_path is required")
        return pd.read_parquet(self.config.meld_path)

    def load_cms_benchmark(self) -> pd.DataFrame:
        if not self.config.cms_benchmark_path:
            raise ValueError("config.cms_benchmark_path is required")
        return pd.read_parquet(self.config.cms_benchmark_path)

    # ------------------------------------------------------------------
    # Block runners
    # ------------------------------------------------------------------
    def run_block_a(self, scales: Dict[str, np.ndarray]) -> Dict[str, Any]:
        """Cronbach's alpha + KR-20 for each multi-item scale."""
        results = {}
        for name, items in scales.items():
            is_binary = np.all(np.isin(items, [0.0, 1.0]))
            alpha_fn = kr20 if is_binary else cronbach_alpha
            alpha_val = alpha_fn(items)
            ci = bootstrap_ci(
                items,
                lambda x: alpha_fn(x),
                n_boot=self.config.n_bootstrap,
                rng=self._rng,
            )
            results[name] = {
                "statistic": "KR-20" if is_binary else "alpha",
                "value": alpha_val,
                "ci_low": ci[0], "ci_high": ci[1],
                "pass": bool(alpha_val >= self.config.alpha_threshold),
            }
        self.report.block_a = results
        return results

    def run_block_b(
        self,
        meld_prev: Dict[str, float],
        cms_prev: Dict[str, float],
    ) -> Dict[str, Any]:
        """Bias, MAPE, Bland-Altman, Lin's CCC across shared indications."""
        shared = sorted(set(meld_prev) & set(cms_prev))
        m = np.array([meld_prev[k] for k in shared])
        c = np.array([cms_prev[k] for k in shared])
        mean_bias, lo, hi = bland_altman_loa(m, c)
        results = {
            "indications": shared,
            "bias": prevalence_bias(m, c),
            "mape": mape(m, c),
            "loa_lower": lo,
            "loa_upper": hi,
            "lin_ccc": lin_ccc(m, c),
        }
        self.report.block_b = results
        return results

    def run_block_c(self, data: pd.DataFrame, model_spec: str) -> Dict[str, Any]:
        """CFA with configurable model specification (lavaan/semopy syntax)."""
        results = fit_cfa(data, model_spec)
        results["pass"] = bool(
            results["CFI"] >= self.config.cfi_threshold
            and results["TLI"] >= self.config.tli_threshold
            and results["RMSEA"] <= self.config.rmsea_threshold
            and results["SRMR"] <= self.config.srmr_threshold
        )
        self.report.block_c = results
        return results

    def run_block_d(
        self, meld_strata: pd.DataFrame, cms_strata: pd.DataFrame,
        group_col: str = "stratum", value_col: str = "proportion",
    ) -> Dict[str, Any]:
        """SMD across strata. Both frames: ['stratum', 'proportion']."""
        merged = meld_strata.merge(
            cms_strata, on=group_col, suffixes=("_meld", "_cms")
        )
        merged["smd"] = [
            smd_binary(r[f"{value_col}_meld"], r[f"{value_col}_cms"])
            for _, r in merged.iterrows()
        ]
        merged["pass"] = merged["smd"].abs() <= self.config.smd_threshold
        results = merged.to_dict(orient="records")
        self.report.block_d = {"strata": results}
        return self.report.block_d

    def run_block_e(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Little's MCAR test + overall missing-rate summary."""
        results = littles_mcar_test(df)
        results["missing_rate_per_col"] = df.isna().mean().to_dict()
        self.report.block_e = results
        return results

    def run_block_f(
        self,
        gamma: np.ndarray,
        m_probs: np.ndarray,
        u_probs: np.ndarray,
        t_match: float = 8.0,
        t_nonmatch: float = 0.0,
    ) -> Dict[str, Any]:
        """Fellegi-Sunter: weight every candidate pair and apply decision rule."""
        w = fellegi_sunter_weights(m_probs, u_probs, gamma)
        decisions = fs_decision(w, t_match, t_nonmatch)
        results = {
            "match_rate": float((decisions == 1).mean()),
            "nonmatch_rate": float((decisions == 0).mean()),
            "clerical_review_rate": float((decisions == -1).mean()),
            "weight_p50": float(np.quantile(w, 0.5)),
            "weight_p95": float(np.quantile(w, 0.95)),
        }
        self.report.block_f = results
        return results

    def run_block_g(self, pairs: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> Dict[str, Any]:
        """Cohen's kappa for each (claims, EMR) pair per condition."""
        results = {}
        for cond, (a, b) in pairs.items():
            k = cohens_kappa(a, b)
            results[cond] = {
                "kappa": k,
                "pass": bool(k >= self.config.kappa_threshold),
            }
        self.report.block_g = results
        return results

    def run_block_h(self, series: Dict[str, np.ndarray]) -> Dict[str, Any]:
        """Mann-Kendall + CUSUM for each sentinel indicator."""
        results = {}
        for name, x in series.items():
            mk = mann_kendall(x)
            cusum_hits = cusum_control(x)
            results[name] = {
                **mk,
                "cusum_flag_count": int(cusum_hits.sum()),
                "pass": bool(mk["p_value"] >= 0.05),
            }
        self.report.block_h = results
        return results

    def run_block_i(
        self,
        y_true: np.ndarray,
        y_prob: np.ndarray,
        label: str = "outcome",
    ) -> Dict[str, Any]:
        """AUROC, Brier, calibration slope/intercept."""
        results = {
            "outcome": label,
            "auroc": auroc(y_true, y_prob),
            "brier": brier_score(y_true, y_prob),
            **calibration_slope_intercept(y_true, y_prob),
        }
        self.report.block_i[label] = results
        return results

    # ------------------------------------------------------------------
    # End-to-end orchestration
    # ------------------------------------------------------------------
    def run_all(self, inputs: Dict[str, Any] | None = None) -> ValidationReport:
        """
        Runs every block for which the required inputs are supplied. The
        ``inputs`` dict keys mirror ``run_block_*`` argument names.

        Missing inputs cause the corresponding block to be skipped (with a
        logged warning), rather than raising -- useful for partial runs.
        """
        inputs = inputs or {}
        dispatch = [
            ("block_a", self.run_block_a, ("scales",)),
            ("block_b", self.run_block_b, ("meld_prev", "cms_prev")),
            ("block_c", self.run_block_c, ("cfa_data", "cfa_model")),
            ("block_d", self.run_block_d, ("meld_strata", "cms_strata")),
            ("block_e", self.run_block_e, ("missing_df",)),
            ("block_f", self.run_block_f, ("gamma", "m_probs", "u_probs")),
            ("block_g", self.run_block_g, ("kappa_pairs",)),
            ("block_h", self.run_block_h, ("sentinel_series",)),
            ("block_i", self.run_block_i, ("y_true", "y_prob")),
        ]
        for name, fn, required in dispatch:
            if all(k in inputs for k in required):
                try:
                    fn(*[inputs[k] for k in required])
                except Exception as exc:
                    logger.warning("Block %s failed: %s", name, exc)
            else:
                logger.info("Skipping %s (missing %s)",
                            name, set(required) - set(inputs))
        return self.report

    def save_report(self, path: str | Path) -> None:
        self.report.to_json(path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _main() -> None:
    parser = argparse.ArgumentParser(description="Run the MELD validation pipeline.")
    parser.add_argument("--config", type=str, default=None,
                        help="YAML config file path (optional)")
    parser.add_argument("--out", type=str, default="validation_report.json",
                        help="Where to write the JSON report")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )

    cfg = ValidationConfig()
    if args.config:
        import yaml
        with open(args.config) as f:
            user = yaml.safe_load(f) or {}
        for k, v in user.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)

    validator = MELDValidator(config=cfg)
    logger.info("MELDValidator initialized with config: %s", cfg)
    # Users are expected to subclass and wire up site-specific data loading.
    # Without data, run_all() will simply log skip messages for every block.
    report = validator.run_all()
    validator.save_report(args.out)
    logger.info("Report written to %s", args.out)


if __name__ == "__main__":
    _main()
